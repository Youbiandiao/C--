#ifndef COPYBINARYTREE_H
#define COPYBINARYTREE_H

btlink copy_btree_recursive(btlink btree);
btlink copy_btree_nonrecursive(btlink btree);

#endif